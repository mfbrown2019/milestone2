const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan');
const path = require('path');
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 8080; // Step 1

// Data parsing
app.use(express.json());
app.use(cors());

// Step 2
const MONGODB_URI = 'mongodb+srv://Jovany:Testpass@clustertest.ibp2qr7.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(MONGODB_URI || 'mongodb://localhost/27017', {
    maxPoolSize: 20,
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoose.connection.on('connected', () => {
    console.log('Mongoose is connected!!!!');
});

// Schema for users of app
const UserSchema = new mongoose.Schema({
    id: String,
    title: String,
    Category: String,
    Due: String,
    Location: String,
    status: String,
    content: String
});

//Model
const User = mongoose.model('users', UserSchema);
//User.createIndexes(); // check what is this

app.post("/register", (req, resp) => {
    const data = req.body;
    console.log(data);

    const newuserdata = new User(data);     // instance of the model
    try {
        newuserdata.save();                 // just use this to save
	    console.log("Data has been saved!");
        return resp.json({
            msg: 'Your data has been saved!!!!!!'
        });
    } catch {
	    console.log("Did not save...");
        resp.status(500).json({ msg: 'Sorry, internal server errors' });
        return;
    }
});

// HTTP request logger
app.use(morgan('tiny'));
//app.use('/', milestone3_createDB.txt);
// app.use('/api', routes);


// Routes
app.get('/', (req, resp) => {

    User.find({  })
        .then((data) => {
            console.log('Data: ', data);
            resp.json(data);
        })
        .catch((error) => {
            console.log('error: ', error);
        });
});

// app.get('/api', (req, resp) => {
//     const data =  {
//         username: 'peterson',
//         age: 5
//     };
//     resp.json(data);
// });


app.listen(PORT, console.log(`Server is starting at ${PORT}`));


// const UserSchema = new mongoose.Schema ({
//     title: String,
//     body: String,
//     date: {
//         type: String,
//         default: Date.now()
//     }
// });
// const testdata =  {
// 	name: 'peterson',
// 	email: 'peters'
// 	//date: 5
// };
// app.post("/register", (req, resp) => {
//     const data = req.body;
//     console.log(data);

//     const newuserdata = new User(data);
//     //const newuserdata = new User(testdata); // instance of the model

//     newuserdata.save((error) => {
//         if (error) {
//             resp.status(500).json({ msg: 'Sorry, internal server errors' });
//             return;
//         }
//         // BlogPost
//         return resp.json({
//             msg: 'Your data has been saved!!!!!!'
//         });
//     });
//app.post("/register", async (req, resp) => {
// 	try {
// 		//const newuserdata = new User(testdata);
// 		await newuserdata.save();
//         // await MONGODB_URI.collection('ClusterTest').save(({$push: {newuserdata}}));
// 		// console.log(newuserdata);
// 		console.log(testdata);
// 		//await MONGODB_URI.collection('ClusterTest').save(({$push: {newuserdata}}));
// 		//console.log(newuserdata);
// 	} catch (e) {
// 		resp.send("Something Went Wrong");
// 	}
// });