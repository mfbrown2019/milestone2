const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan');
const path = require('path');
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 8080; // Step 1

// Data parsing
app.use(express.json());
app.use(cors());

// Step 2
const MONGODB_URI = 'mongodb+srv://Jovany:Testpass@clustertest.ibp2qr7.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(MONGODB_URI || 'mongodb://localhost/27017', {
    maxPoolSize: 20,
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoose.connection.on('connected', () => {
    console.log('Mongoose is connected!!!!');
});

// Schema for users of app
const UserSchema = new mongoose.Schema({
    id: String,
    title: String,
    Category: String,
    Due: String,
    Location: String,
    status: String,
    content: String
});

// const UserSchema = new mongoose.Schema ({
//     title: String,
//     body: String,
//     date: {
//         type: String,
//         default: Date.now()
//     }
// });

//Model
const User = mongoose.model('users', UserSchema);
//User.createIndexes(); // check what is this


// const testdata =  {
// 	name: 'peterson',
// 	email: 'peters'
// 	//date: 5
// };

const testdata =  {
	title: 'peterson',
	body: 'peters'
};

const newuserdata = new User(testdata); // instance of the model
try {
    newuserdata.save();                 // just use this to save
	console.log("Data has been saved!");
} catch {
	console.log("Did not save...");
}

// app.post("/register", async (req, resp) => {
// app.get("/register", async (req, resp) => {	
// 	try {
// 		//const newuserdata = new User(testdata);
// 		await newuserdata.save();
//         // await MONGODB_URI.collection('ClusterTest').save(({$push: {newuserdata}}));
// 		// console.log(newuserdata);
// 		console.log(testdata);
// 		//await MONGODB_URI.collection('ClusterTest').save(({$push: {newuserdata}}));
// 		//console.log(newuserdata);
// 	} catch (e) {
// 		resp.send("Something Went Wrong");
// 	}
// });

// HTTP request logger
app.use(morgan('tiny'));
// app.use('/api', routes);


// Routes
app.get('/', (req, res) => {

    User.find({  })
        .then((data) => {
            console.log('Data: ', data);
            res.json(data);
        })
        .catch((error) => {
            console.log('error: ', error);
        });
});

app.get('/api', (req, res) => {
    const data =  {
        username: 'peterson',
        age: 5
    };
    res.json(data);
});


app.listen(PORT, console.log(`Server is starting at ${PORT}`));
